package com.cy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalSysApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalSysApplication.class, args);
	}

}
